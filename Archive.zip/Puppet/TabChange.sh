for i in {1..100000}
do
  xdotool key ctrl+Page_Up
  sleep $(( ( RANDOM % 60 )  + 180 ))
done	

